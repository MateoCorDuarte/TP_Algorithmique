#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <stdio.h>
#include <bits/stdc++.h>



using namespace std;

int multi_2(int integer);
int divise_3(int integer);
int test(int input);
int sequenceDivisible (int k);
void store_sub_sequence(vector<int>& elements, int index_sous_sequence, int Max_sub_seq);

int X;
int entree = 1;
std::string Output = "1";

int main() {

    /* activer Exercice_1
    std::cout << "Enter X please : \n" << std::endl;
    std::cin >> X;
     test(entree);
    */
    sequenceDivisible(2);

    //

    return 0;
}
/*
 * Cette solution va *2 et /3 jusqu'à ce qu'on obtienne le X scanner en entrée
 */

int multi_2(int integer) {
    integer =  2* integer;
    return integer;
}
int divise_3(int integer) {
    integer = integer / 3;
    return integer;
}
int test(int input) {
    //entree=  multi_2(input); // entree prend 2
    //Output += "*2";
    //std::cout << entree << "\n";
    while (entree <X){
        entree=  multi_2(entree);
        //std::cout << "une fois ";
        Output += "*2";
    }
    if ( entree > X) {
        entree = divise_3(entree);
        Output += "/3";
        if (entree < X) {
            entree = multi_2(entree);
            Output += "*2";
        }
    }
    else if (entree < X) {
        entree = multi_2(entree);
        Output += "*2";
        if (entree > X) {
            entree = divise_3(entree);
            Output += "/3";
        }
    }
    else if (entree = X) {
        Output += "\n";
        //std::cout << "egalite \n";
    }
    else {
        std::cout << "You're mistaking buddy !";
    }
    std :: cout << Output <<"="<<X;
    return 0;
}
/*
    if (X == entree) {
        for (int i= 0 ; i<nb_multiplication;i++){
            std::cout<< "1*2";
        }
    }
    else if (X != 2*entree ){
        int interation = (X/2)-1;
        for
    }
    std::cout << "Iam out ";
    std::cout << entree;
    return 0;
}
*/
/* exercice 3 :
 * lire à partir d'un input file .txt (done)
 * Initialiser un parametre K (done)
 * détecter la plus longue sections ayant somme(ss-sec) divisible par K (ss sec%k == 0)
 *  Restituer dans un OUTPUT file
*/
int sequenceDivisible (int k) {

    ifstream inputFile("INPMONOSEQ.txt");
    ifstream outputFile("OUTMONOSEQ.txt");
    if (k > 50) {
        cout << "k is too big !";
        return 1;
    } else if (!inputFile.is_open()) {
        cout << "File not open";
        return 1;
    } else {
        string each_line;
        int element_ligne_1;
        vector<int> elements;
        vector<int> a_out;
        if (getline(inputFile, each_line)) {

            std::istringstream StreamLine1(each_line); //istringstream for the line 1

            if (StreamLine1 >> element_ligne_1) { //passage du premier entier n donnant la taille du tableau dans lequel on cherche la ss-sequence
                cout <<"longueur echantillon : " <<element_ligne_1<< endl;
            } else {
                return 1;
            }
        } //validé

        if (getline(inputFile, each_line)) {


            int Sum_Max_Seq = 0;
            std::istringstream StreamLine2(each_line);
            int var_traitement = element_ligne_1 - 1;
            int num_elem = 1;
            int index_sous_sequence;
            int Max_sub_seq = 0;


            int element_traitement; // variable temporaire stocker valeur du streamline
            while (StreamLine2 >> element_traitement) { //extraction des integers pour trouver sous-sequence
                //cout << "valeurs int :  "<<element_traitement << "\n";
                elements.push_back(element_traitement);
            } // stockage element input dans vector elements


            for (int j = 0; j < element_ligne_1; j++) {
                int Sum = 0;

                for (int i = j; i < element_ligne_1; i++) {
                    Sum += elements[i];

                    if (Sum % k == 0 && i-j + 1 > Max_sub_seq) { //Conditions sous-séquence
                        //Ici, la sous sequence maximale serait de taille (i - j)+1
                        Max_sub_seq = i-j + 1;
                        index_sous_sequence = j; //indexe de début de subsequence dans le tabeau elements
                        Sum_Max_Seq = Sum;
                    }

                }
            }
            store_sub_sequence(elements,index_sous_sequence,Max_sub_seq);
            cout << "Sum = "<<Sum_Max_Seq<<endl ;
        }


}
}


void store_sub_sequence(vector<int>& elements, int index_sous_sequence, int Max_sub_seq) {
    std::cout << "La sous-séquence la plus longue : \n";
    for (int i = index_sous_sequence; i < index_sous_sequence + Max_sub_seq; ++i) {
        cout << "a[" << Max_sub_seq +1- i << "] = " << elements[Max_sub_seq - i] << "\n";
    }
}







