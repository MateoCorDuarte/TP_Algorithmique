#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <stdio.h>
#include <bits/stdc++.h>



using namespace std;

int multi_2(int integer);
int divise_3(int integer);
int test(int input);
int sequenceDivisible (int k);

int X;
int entree = 1;
std::string Output = "1";

int main() {

    /* activer Exercice_1
    std::cout << "Enter X please : \n" << std::endl;
    std::cin >> X;
    */
    sequenceDivisible(49);

    //test(entree);

    return 0;
}
/*
 * Cette solution va *2 et /3 jusqu'à ce qu'on obtienne le X scanner en entrée
 */

int multi_2(int integer) {
    integer =  2* integer;
    return integer;
}
int divise_3(int integer) {
    integer = integer / 3;
    return integer;
}
int test(int input) {
    //entree=  multi_2(input); // entree prend 2
    //Output += "*2";
    //std::cout << entree << "\n";
    while (entree <X){
        entree=  multi_2(entree);
        //std::cout << "une fois ";
        Output += "*2";
    }
    if ( entree > X) {
        entree = divise_3(entree);
        Output += "/3";
        if (entree < X) {
            entree = multi_2(entree);
            Output += "*2";
        }
    }
    else if (entree < X) {
        entree = multi_2(entree);
        Output += "*2";
        if (entree > X) {
            entree = divise_3(entree);
            Output += "/3";
        }
    }
    else if (entree = X) {
        Output += "\n";
        //std::cout << "egalite \n";
    }
    else {
        std::cout << "You're mistaking buddy !";
    }
    std :: cout << Output <<"="<<X;
    return 0;
}
/*
    if (X == entree) {
        for (int i= 0 ; i<nb_multiplication;i++){
            std::cout<< "1*2";
        }
    }
    else if (X != 2*entree ){
        int interation = (X/2)-1;
        for
    }
    std::cout << "Iam out ";
    std::cout << entree;
    return 0;
}
*/
/* exercice 3 :
 * lire à partir d'un input file .txt (done)
 * Initialiser un parametre K (done)
 * détecter la plus longue sections ayant somme(ss-sec) divisible par K (ss sec%k == 0)
 *  Restituer dans un OUTPUT file
*/
int sequenceDivisible (int k) {

    ifstream inputFile("INPMONOSEQ.txt");

    if (k>50) {
        cout <<"k is too big !";
        return 1;
    }
    else if (!inputFile.is_open()) {
        cout << "File not open";
        return 1;
    }
    else {

        string each_line;
        vector<int> elements;
        vector<int> a_out;

        while (getline(inputFile, each_line)) {
            int element_ligne;
            std::istringstream toParse(each_line);
            //cout << "chaque ligne :" << each_line << endl;


            while (toParse >> element_ligne) { //extraction des integers depuis le istringstream
                cout << "valeurs int :  "<<element_ligne << "\n";
                elements.push_back(element_ligne);
            };
        }
        int Sum ;
        int iterator = 0;
        for (int j = 0; j<elements[0];j++) {
            iterator++ ;
            cout <<"a["<<j<<"] = " << elements[j] <<"\n";
            Sum += elements[j];

        }
        cout <<"iterateur : "<<iterator<<endl ;
        cout << "Sum = "<<Sum <<endl;


    }
}






